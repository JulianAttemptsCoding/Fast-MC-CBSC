# CBSC-ZDC v3 handoff QA report

**Date:** 2026-08-13  
**Scope:** research/specification/package QA, not model-training or Geant4-fidelity QA.

## Input verification

- Input archive: `upload/CBSC_ZDC_audit_bundle_20260812.zip`.
- SHA-256: `ec4f044695401d438d47019012b9d0a1bedda59da5d5d211a97f34e91b5a0432`.
- `unzip -t`: no errors.
- `verify_bundle.py`: 1,512/1,512 manifested files verified, 0 missing,
  changed, or originally unlisted.
- Critical active-code hashes were recorded and used by the overlay verifier.

## Research and design QC

- Reconciled the earlier improvement report against active model/trainer/data
  code, current operating rules, current scheduler evidence, current gate file,
  and active L40S/3090 hardware state.
- Added two audited defects omitted from the earlier short plan:
  incident-axis-relative geometry and support-logit/Gumbel-noise calibration.
- Revised the response implementation so a quantile-derived safety cap is not
  silently treated as guaranteed truth support. The new specification builds a
  train-only maximum envelope and verifies every selected event.
- Revised the first critic topology from a cross-pod live critic to a
  synchronous single-L40S implementation. A filesystem-connected 3090 cannot
  carry the generator autograd graph; asynchronous critic training is therefore
  a later staleness ablation.
- Preserved actual archive diagnostic thresholds instead of substituting
  stricter values from earlier planning.
- Source register: 42 primary papers/preprints, official PyTorch pages, and
  internal evidence categories. Cross-detector headline results are explicitly
  non-transferable.
- Decision log: 76 accepted, conditional, deferred, or rejected interventions
  with a fastest falsification/QA check.

## Package contents and syntax QA

- Root overlay files: 16 including its self-excluded manifest.
- Handoff manifest entries: 15.
- Manifest verification: 0 missing, 0 changed.
- YAML documents parsed: 3/3.
- CSV tables parsed:
  - experiment matrix: 28 data rows;
  - file-change map: 27 data rows.
- Research links: 42 unique URLs.
- Python verifier: `py_compile` passed.
- Placeholder scan: no `TODO`, `TBD`, `PLACEHOLDER`, or `FIXME` markers.
- ZIP integrity: no compressed-data errors.

## Clean-overlay integration QA

The original archive was extracted into a new temporary directory, then the
root overlay was extracted on top. The handoff verifier reported:

- all 11 audited critical base files matched their expected SHA-256;
- all 15 handoff manifest entries matched;
- all YAML/CSV files parsed;
- exit status 0 with `--require-audited-base`.

The original `verify_bundle.py` subsequently listed the 15 new overlay files as
“not in manifest.” This is expected: its August 12 manifest is immutable
evidence for the pre-overlay archive. The new files are covered by
`specs/improvement_v3/MANIFEST.sha256`; the implementation agent must generate
a new versioned repository/bundle manifest rather than rewriting historical
evidence.

## Important execution boundary

The current analysis runtime does not contain PyTorch. Therefore the original
reported repository test suite and the proposed gradient/spline/model tests
could not be executed here. `pytest` itself was installed only into a temporary
directory for diagnosis, but collection remains impossible without PyTorch.
The one-shot prompt makes the project’s supported PyTorch environment and the
complete new test catalog mandatory before any training.

No new generator was trained, no critic was trained, and no validation/test
metric was produced. None of the proposed improvements is claimed to work.
`PHYSICS VALIDATION NOT ESTABLISHED`.

