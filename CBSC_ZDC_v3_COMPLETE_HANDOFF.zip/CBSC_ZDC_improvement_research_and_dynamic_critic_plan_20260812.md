# CBSC-ZDC improvement research and dynamic-critic plan

**Date:** 2026-08-12  
**Scope:** source-backed diagnosis, ranked improvements, dynamic low-level classifier design, experiment plan, QA/QC gates, and complete intervention decision log for the audited `CBSC_ZDC_audit_bundle_20260812.zip` snapshot.  
**Evidence boundary:** this report does not claim results from experiments that have not been run. Numerical acceptance thresholds labeled **proposed** are preregistration recommendations, not observed outcomes.

## 1. Executive decision

The project should **not** attach a classifier loss to the current full `model.sample()` path and expect it to train the generator. That path is decorated with `@torch.no_grad()`, and its Bernoulli, categorical, and hard exact-Gumbel-top-k decisions are nondifferentiable. As implemented, the naïve classifier loss supplies **no generator gradient**. Removing only `@torch.no_grad()` would still leave the discrete response visibility, mixture selection, first layer, active-layer mask, counts, and support decisions without an ordinary pathwise gradient.

The highest-value sequence is:

1. **Finish and evaluate the corrected one-way learning-rate anneal** before changing model science. The bundle proves the previous scheduler repeatedly reheated because a six-epoch `T_max` was restored from an ancestor checkpoint. Until the controlled replacement reaches its declared endpoint, architecture comparisons are confounded.
2. **Repair the response distribution.** Make the Bernoulli hurdle the *only* zero atom and model the positive total response with a bounded conditional spline or another positive bounded distribution. This directly targets the approximately doubled zero-response rate and removes an identifiable code-level defect.
3. **Make rare ECAL starts hierarchical.** Predict `starts_in_ECAL` separately, then predict the first HCAL layer conditionally. This directly targets the roughly two-orders-of-magnitude layer-0 deficit.
4. **Model longitudinal dependence explicitly.** Replace conditionally independent active-layer and layer-count draws with a compact span/gap model or an autoregressive layer model, selected after measuring truth transition/gap statistics.
5. **Add correlation and support-topology diagnostics before changing the support sampler.** The current graph scores plus exact Gumbel top-k preserve exact counts but cannot represent every possible correlated subset law. Establish the missing correlations first.
6. **Then run a staged dynamic conditional critic.** Start with share-only and profile-only differentiable subproblems under truth-forced discrete structure. Add a structured support estimator only if topology diagnostics prove it is necessary. Do not jump directly to a relaxed full shower.

The recommendation for “previous outputs or best epoch” is a **bounded, stratified mixed replay buffer** dominated by fresh samples—not all historical outputs, not only a best epoch, and not a classifier reset every 20 epochs. A live critic should update continually; replay should contain current fakes, a recent FIFO window, and a small set of versioned anchor checkpoints. History-buffer precedent exists, while GAN convergence research supports regularized continuous updates rather than repeated cold restarts ([SimGAN](https://arxiv.org/abs/1612.07828), [TTUR](https://arxiv.org/abs/1706.08500), [Mescheder et al.](https://arxiv.org/abs/1801.04406)).

## 2. Current evidence that constrains the solution

### 2.1 What is established in the bundle

| Item | Audited fact | Consequence |
|---|---:|---|
| Geometry | 6,790 channels, 65 layers | Sparse graph/point representation is appropriate; dense-image losses are not automatically appropriate. |
| Full frozen split | 612,482 train / 76,158 validation / 76,300 test | There is enough training data for clean generator/critic partitions; test need not be touched during development. |
| Current pilot | 26,624 train / 6,656 validation | Existing training used only about 4.3% of the available training split, so capacity conclusions are premature. |
| Low-level hybrid C2ST | approximately 0.862–0.873 for reported accepted checkpoints | Real and generated showers remain readily separable. |
| High-level C2ST | approximately 0.895–0.929; condition-only control 0.5 | The evaluator is detecting shower differences, not merely four-momentum sampling differences. |
| Downstream reconstruction | FastMC errors about 1.4–2.5 times Geant4 | The mismatch is operationally relevant, not only a cosmetic histogram difference. |
| Dominant defects | excess zeros, severely deficient ECAL layer 0, response bias in an older region, width/morphology mismatch | Improvements must be judged module-by-module, not by validation NLL alone. |
| Scheduler | inherited `T_max=6660`, exactly six epochs at 1,110 updates/epoch; cosine therefore repeated over a 12-epoch period | Complete the corrected schedule before causal model ablations. |
| Current claim status | physics validation not established; three generator seeds not run | One favorable run is not enough for a scientific claim. |

The bundle itself sets a provisional high-level C2ST AUROC gate of `0.65`. That is a project heuristic, not a theorem: a low AUROC can mean that a particular classifier failed to detect a difference, whereas a high AUROC is positive evidence of separability. Classifier two-sample testing is most interpretable with held-out data and controlled capacity ([C2ST](https://arxiv.org/abs/1610.06545)).

### 2.2 Exact gradient obstruction in the current implementation

The relevant code paths are:

- `src/cbsc_zdc/models/system.py`: `CBSCZDC.sample()` has `@torch.no_grad()`.
- `src/cbsc_zdc/models/response.py`: visibility uses `torch.bernoulli`; mixture component uses `Categorical.sample()`.
- `src/cbsc_zdc/models/profile.py`: first layer is categorical and activity uses Bernoulli draws under `@torch.no_grad()`.
- `src/cbsc_zdc/models/counts.py`: each layer count is a categorical draw.
- `src/cbsc_zdc/models/support.py`: `exact_k_mask()` perturbs scores, sorts them, constructs integer ranks, and returns a Boolean `rank < k` mask.

Therefore:

\[
\nabla_\theta L_{\mathrm{critic}}(D(G_\theta(p_4))) = 0
\]

for the current `sample()` API. If the outer `no_grad` is removed, the ordinary pathwise gradient still does not cross the sampled discrete variables. Gumbel noise alone does not make `argsort`, rank construction, or a Boolean mask differentiable. Differentiable categorical relaxations and structured-subset estimators exist, but they introduce bias/variance and must be isolated as experiments ([Gumbel-Softmax](https://arxiv.org/abs/1611.01144), [Stochastic Softmax Tricks](https://arxiv.org/abs/2006.08063), [SIMPLE](https://arxiv.org/abs/2210.01941)).

## 3. Ranked improvement program

### Priority 0 — finish the corrected baseline

**Change:** no architecture change. Let the corrected single 24-epoch anneal reach its declared endpoint, evaluate the accepted checkpoint using the existing deterministic external metrics, and record all seeds/config hashes.

**Why first:** the bundle establishes an exact scheduler confound. Changing the architecture before the controlled baseline finishes destroys attribution.

**QA:** verify in the epoch log that learning rate is monotone non-increasing over the continuation; verify restored scheduler `T_max` equals remaining updates; verify batch size, optimizer, split manifest, model state, and loss weights match the control.

**Falsification:** if the LR rises at any point other than numerical noise, the correction is not the claimed one-way anneal and the run cannot serve as the baseline.

### Priority 1 — repair the response hurdle and positive branch

#### Current defect

The response head has a Bernoulli visibility model, but the sampled positive-component latent is transformed with `expm1`, clamped with `clamp_min(0)`, capped, and then visibility is cleared when the resulting total is zero. A nominally positive component can therefore create a second zero atom. This is a direct, implementation-level explanation for excess zero response.

#### Recommended model

Keep the explicit hurdle:

\[
V\sim\mathrm{Bernoulli}(\pi(p_4)),\qquad T=0\ \text{if}\ V=0.
\]

For `V=1`, define the event-specific cap `C(p_4)` only after confirming that it does not truncate truth, and model

\[
r=\frac{T}{C(p_4)}\in(0,1)
\]

with a conditional one-dimensional rational-quadratic spline. At sampling, force `r` strictly inside `(epsilon, 1-epsilon)` and set `T=C r`; never create zero with a clamp. Neural spline flows give flexible monotonic transforms with exact likelihoods and efficient sampling ([Neural Spline Flows](https://arxiv.org/abs/1906.04032)). CaloFlow provides calorimeter-specific evidence that conditional normalizing flows can produce stable, high-fidelity distributions and can be evaluated with real/fake classifiers ([CaloFlow](https://arxiv.org/abs/2106.05285)).

**Files to change:**

- replace the positive distribution in `src/cbsc_zdc/models/response.py`;
- add response transform/cap parameters to the experiment config schema;
- add response calibration diagnostics in `src/cbsc_zdc/evaluation/metrics.py` or the project’s active external-metrics module;
- add unit tests that `visible => total_response > 0`, `not visible => total_response == 0`, no sample equals the cap except within floating-point coincidence, and NLL/sample transforms round-trip.

**Before training:** compute the Geant4 fraction above the proposed cap globally and in each 25-GeV primary-energy bin. **Proposed gate:** if more than 0.01% of training truth exceeds the cap, revise the cap instead of silently clipping.

**Evaluation:** zero rate with Wilson/bootstrap confidence intervals; positive-response quantiles; mean, resolution, skew and tails by energy; PIT or rank-calibration histograms; cap pile-up; downstream reconstructed energy.

**Fastest falsification:** sample 100,000 events from an untrained/partially trained head and assert that all zeros arise only from `V=0`. If the response mismatch remains while zero duplication disappears, the code defect was real but not the entire modeling defect.

### Priority 2 — separate the rare ECAL-start decision

The reported layer-0 energy deficit is roughly two orders of magnitude. A single 65-way first-layer categorical loss can allocate little gradient to a rare ECAL-start class.

Use the hierarchy:

\[
z_{\mathrm{ECAL}}\sim\mathrm{Bernoulli}(p_4,T),
\]

and, if `z_ECAL=0`,

\[
f_{\mathrm{HCAL}}\sim\mathrm{Categorical}(1,\ldots,64\mid p_4,T).
\]

If `z_ECAL=1`, set the first layer exactly to 0. Begin with the true unweighted Bernoulli likelihood. Class weighting or focal loss can improve recall while corrupting calibrated prevalence, so use it only with an explicit calibration correction.

**Files to change:** `src/cbsc_zdc/models/profile.py`, the profile loss construction, config schema, and unit tests for all visible/non-visible branches.

**QA:** report ECAL-start precision/recall *and* calibration, but select on prevalence and energy closure rather than recall alone. Stratify by energy and incidence direction. Confirm that the hierarchy leaves total response and exact layer closure unchanged.

**Fastest falsification:** teacher-force truth totals and compare sampled first-layer frequencies. If layer-0 prevalence closes but generated layer-0 energy remains low, the remaining defect lies in active/profile/share modeling rather than first-layer classification.

### Priority 3 — model longitudinal activity and counts jointly

The current active-layer logits are computed independently for every layer given condition, total, and first layer. Counts are also sampled independently per layer given condition, that layer’s energy, activity, and embedding. This misses transition, gap, and cross-layer-count dependence.

First measure:

- `P(active_l | active_{l-1}, first, p4)`;
- distribution of last active layer;
- number and length of inactive gaps inside `[first,last]`;
- adjacent and long-range layer-count correlations after conditioning on layer energy;
- truth correlation matrices and their bootstrap floors.

Then choose the smallest model justified by the data:

1. **Span-plus-gaps candidate:** predict last active layer and then a sparse gap mask if at least 99% (**proposed diagnostic threshold**) of patterns are well described by a contiguous span with few gaps.
2. **Autoregressive candidate:** otherwise model `a_l | a_{<l}, p4, T, first` and `k_l | k_{<l}, a, E_layer, p4` with a small causal transformer or GRU. Teacher-force during NLL training and sample sequentially.

Layer-to-layer conditional flows have improved high-granularity calorimeter fidelity, supporting explicit longitudinal dependence rather than independent layers ([L2LFlows](https://arxiv.org/abs/2302.11594)).

**QC:** retain exact feasibility masks (`k=0` on inactive layers, positive count on active layers, count no larger than geometry or threshold permits). Benchmark the extra 65-step sampling latency. Reject the autoregressive version if it gives no statistically resolved correlation improvement over the compact span model.

### Priority 4 — improve flow coupling before enlarging the network

Screen minibatch optimal-transport conditional flow matching for the 65-dimensional profile flow. OT-CFM reports simpler flows and favorable training/sampling behavior compared with independent coupling in its studied settings ([OT-CFM](https://arxiv.org/abs/2302.00482)); the general conditional-flow-matching basis is described by [Flow Matching](https://arxiv.org/abs/2210.02747).

Use narrow condition bins or a condition-aware transport cost so that samples are not coupled across physically dissimilar `p4`, total response, visibility, or active masks. Start with the profile flow. Do **not** immediately apply minibatch OT to the share flow because showers have different hard supports; an arbitrary transport match across incompatible supports can teach the wrong geometry.

**QC:** identical model, data order, optimizer, steps and seeds; only the coupling changes. Measure flow loss, number of Euler steps required for metric saturation, profile covariance, C2ST, and wall time.

### Priority 5 — diagnose support correlations, then choose a structured remedy

The support field is already a conditional graph score model; it is not static. However, adding independent Gumbel perturbations and taking exact top-k produces a Plackett-Luce-like ranked subset distribution. It preserves exact counts but does not represent every possible correlated subset law.

Add truth/generated metrics for:

- graph-edge co-occupancy and distance-binned co-occupancy;
- connected-component count and component sizes;
- pair-distance and nearest-neighbor distributions;
- radial eccentricity and local density;
- per-layer versions of all metrics, stratified by primary energy and count.

If these metrics show a substantial residual after priorities 1–4, screen one of:

- pairwise/neighborhood auxiliary losses on the support logits;
- a structured subset estimator with exact hard forward samples and a surrogate backward estimator such as SIMPLE;
- an autoregressive/energy-based subset model only if the simpler estimator fails.

SIMPLE specifically targets gradients for `k`-subset sampling and reports lower bias/variance than straight-through Gumbel estimators in its experiments ([SIMPLE](https://arxiv.org/abs/2210.01941)). Stochastic Softmax Tricks provide a broader framework for differentiable combinatorial relaxations ([SST](https://arxiv.org/abs/2006.08063)). These are research candidates, not guaranteed fixes for this detector.

## 4. Exact design for the dynamic low-level classifier

### 4.1 Role separation

Use three different models; never reuse one score as both a training signal and the publication claim.

| Model | Data | Updated? | Purpose |
|---|---|---:|---|
| Live conditional critic | train-only real partition + current/replayed train-condition fakes | continually | supplies generator loss |
| Critic generalization monitor | disjoint train-only holdout | evaluation only | detects critic memorization, saturation and stale replay |
| External C2ST ensemble | frozen validation during development; untouched test once | retrained independently per candidate, never backpropagated | unbiased separability measurement |

The original GAN objective establishes the adversarial generator/discriminator idea ([GAN](https://arxiv.org/abs/1406.2661)), but this project needs conditional and stability controls. A projection discriminator is a principled way to incorporate conditions ([Projection Discriminator](https://arxiv.org/abs/1802.05637)). Separate learning rates are supported by TTUR ([TTUR](https://arxiv.org/abs/1706.08500)); zero-centered/R1-style gradient penalties have local-convergence support in lower-dimensional settings ([Mescheder et al.](https://arxiv.org/abs/1801.04406)); spectral normalization is a lightweight discriminator stabilizer ([Spectral Normalization](https://arxiv.org/abs/1802.05957)).

### 4.2 Clean data partition

From the existing 612,482-event training split, use a deterministic event-ID hash to propose:

- `generator_train`: 551,234 events (90%);
- `critic_real_train`: 30,624 events (5%);
- `critic_monitor_holdout`: 30,624 events (5%).

Keep all 76,158 validation and 76,300 test events outside both generator and critic optimization. Do not put generated validation/test showers in replay. This reduces generator training data by 10%; therefore include a control trained on the same 90% partition so data volume is not confounded. After the method and hyperparameters are frozen, a final refit may reconsider data use, but it needs a newly defined monitor and cannot retroactively change the held-out test protocol.

### 4.3 Staged gradient path

#### D0 — diagnostic-only classifier

Train the current independent C2ST, record permutation importance/feature ablations and localize residuals by module, layer and 25-GeV energy bin. No generator gradient.

#### D1 — share-only critic (**first adversarial experiment**)

Truth-force visibility, total response, first layer, activity, layer budgets, counts and support. Generate only the differentiable share-flow state and decoded positive cell energies on that fixed support. The critic then teaches morphology and cell-energy allocation without needing discrete gradients.

Trainable generator modules: share flow only. Frozen modules: response, profile, counts and support.

#### D2 — profile-only critic

Truth-force visibility, total response, and active mask. Generate only the continuous 65-layer shares. Critic inputs are normalized layer energies plus condition. Train the profile flow only.

#### D3 — support critic

Truth-force counts and layer budgets. Use exact hard support in the forward pass, but compare SIMPLE and one soft top-k relaxation for the backward estimator. The exact decoder remains the output path. Train support scores only.

Before promotion, measure estimator quality on small geometry slices where a finite-difference or enumerated expectation is possible: gradient cosine, relative bias, variance across 100 noise draws, and downstream metric improvement. Reject estimators with high variance or inconsistent finite-difference direction.

#### D4 — full relaxed shadow sampler (**defer**)

Only if D1–D3 each show reproducible benefit, add relaxed Bernoulli/categorical decisions for visibility, mixture, first layer, activity and counts, plus structured top-k support. Maintain two APIs:

- `sample_exact()` for all metrics and production output;
- `sample_relaxed_for_loss()` only for training.

This is the first stage where a single low-level critic can influence the full chain. Gumbel-Softmax supplies a differentiable categorical relaxation that anneals toward discrete samples, but temperature schedules and straight-through bias must be ablated ([Gumbel-Softmax](https://arxiv.org/abs/1611.01144)).

### 4.4 Critic architecture

Use a small conditional multiscale graph critic:

- **Node features:** occupancy; `log1p(E_cell/E0)`; `E_cell/T`; normalized detector coordinates; layer embedding.
- **Local branch:** 3 graph message-passing blocks over the existing detector edges, 96–128 hidden channels.
- **Layer branch:** sum/mean/max pooling per layer followed by a small 1D/attention context block.
- **Global branch:** pooled total, hit count, centroid, radial moments, top-k energy fractions and first/last activity. These are differentiable for D1/D2 with fixed support; omit or soften hard statistics in D3/D4 as required.
- **Conditioning:** encode normalized `p4` and use a projection logit `u(h)+<v(p4),h>`.
- **Regularization:** spectral normalization on critic linear/message-passing layers; zero-centered gradient penalty on normalized real continuous inputs.

Conditioning is mandatory: an unconditional critic can reward the correct marginal shower mixture while permitting the wrong response at a given four-momentum.

### 4.5 Loss and update rule

For normalized critic inputs `x`, use a non-saturating logistic objective:

\[
L_D = \mathbb{E}_{x_r}\,\mathrm{softplus}(-D(x_r,p_4))
    + \mathbb{E}_{x_f}\,\mathrm{softplus}(D(x_f,p_4))
    + \frac{\gamma}{2}\mathbb{E}_{x_r}\|\nabla_{x_r}D(x_r,p_4)\|_2^2,
\]

\[
L_G = L_{\mathrm{base}} + \lambda_{\mathrm{adv}}
      \mathbb{E}_{x_f}\,\mathrm{softplus}(-D(x_f,p_4)).
\]

During the generator step, freeze critic parameters (`requires_grad_(False)`) but **do not detach critic inputs**. During the critic step, detach/no-grad the generator sample.

**Starting screen, explicitly heuristic:** critic Adam `lr=1e-4`, betas `(0,0.9)`; fine-tuning generator `lr=1e-5`; 1 critic step per generator step; R1 coefficient screen `{0.1,1,10}` after input normalization; optional lazy R1 every 16 steps. WGAN-GP is a possible alternative ([WGAN-GP](https://arxiv.org/abs/1704.00028)), but it should not be assumed to solve convergence universally; Mescheder et al. provide counterexamples with finite discriminator updates.

Do not let the adversarial term dominate. On 200 fixed calibration minibatches, calculate for the stage’s trainable module `theta_s`:

\[
\rho=\frac{\|\nabla_{\theta_s}(\lambda_{adv}L_{adv})\|_2}
{\|\nabla_{\theta_s}L_{base}\|_2+\epsilon}.
\]

Run separate fixed-weight experiments targeting median `rho` of 0.05, 0.10 and 0.20. Ramp from zero over the first 10% of fine-tuning updates, then keep the selected lambda fixed. Log gradient cosine between the adversarial gradient and every base-loss component. Do not automatically deploy GradNorm, PCGrad or another symmetric balancing rule: the very recent Lantern preprint reports severe FPD regressions from several symmetric rules in one CaloChallenge Dataset-2 diffusion setting and finds that a conflicting auxiliary loss needs a terminal base-only phase ([Lantern](https://arxiv.org/abs/2607.25060)). This is cautionary single-setting evidence, not a universal prohibition. Include a final 20% base-only cooldown as an ablation.

### 4.6 Replay: how to learn from previous outputs

Do not save every generated event. “All history” grows without bound, overrepresents obsolete weak generators, and allows the critic to win on artifacts the current generator no longer produces. “Best epoch only” is stale and allows cycling back to forgotten defects. Reinitializing the classifier every 20 epochs discards useful boundaries and creates a periodic optimization shock.

Use a fixed-capacity buffer; **starting proposal:** 65,536 fake showers, stratified by:

- 25-GeV primary-energy bin;
- visible/zero response;
- ECAL-start/non-ECAL-start;
- layer/count regime where sample counts permit.

Construct the fake half of each critic minibatch as:

- 50% fresh current-generator samples;
- 25% recent FIFO samples from the latest checkpoints;
- 25% anchors from the corrected baseline and regularly spaced/accepted historical checkpoints.

Store only train-split conditions and the metadata needed for reproducibility: event/condition ID, generation seed, generator checkpoint SHA-256, exact/relaxed API version, and insertion step. Evict within strata by reservoir/FIFO rules. A history of prior refined samples has direct stabilization precedent in SimGAN, but the exact proportions above are proposed and require an ablation ([SimGAN](https://arxiv.org/abs/1612.07828)).

Every 1,000 critic updates, evaluate:

- train and holdout AUROC/log loss;
- AUROC by replay age and generator version;
- fresh-only AUROC;
- real/fake logit histograms;
- generator gradient norm and diversity metrics.

If fresh-only performance deteriorates while mixed-replay performance improves, the critic is learning history rather than the current boundary; raise the fresh fraction or shorten the buffer.

### 4.7 Dual-GPU execution

For a 4090/3090 workstation, begin with one synchronous Python process:

- generator and base loss on the 4090;
- critic and replay minibatches on the 3090;
- copy only normalized critic inputs across devices;
- during a generator step, preserve autograd through the device copy while critic parameters are frozen;
- during a critic step, generate/detach fakes and update only the 3090 critic.

This is slower over PCIe than fully colocated training but preserves a well-defined current critic. Profile it before building asynchronous infrastructure. An asynchronous second process may be tested later by publishing critic snapshots at fixed intervals, but staleness then becomes another experimental variable and needs a matched synchronous control.

### 4.8 Pseudocode with the critical detach boundary

```python
# D step: no generator gradient
set_requires_grad(critic, True)
with torch.no_grad():
    fake_exact_or_stage = generator.sample_stage(batch_p4, truth_structure)
fake_x = make_critic_input(fake_exact_or_stage).to(critic_device)
real_x = make_critic_input(real_shower).to(critic_device).requires_grad_(True)
loss_d = logistic_d_loss(critic(real_x, p4), critic(fake_x.detach(), p4))
loss_d += r1_penalty(critic, real_x, p4, gamma)
optimizer_d.zero_grad(set_to_none=True)
loss_d.backward()
optimizer_d.step()

# G step: freeze D weights, preserve gradient through D input
set_requires_grad(critic, False)
fake_stage = generator.sample_differentiable_stage(batch_p4, truth_structure)
fake_x = make_critic_input(fake_stage).to(critic_device)  # do not detach
loss_adv = torch.nn.functional.softplus(-critic(fake_x, p4)).mean()
loss_g = loss_base + lambda_adv * loss_adv
optimizer_g.zero_grad(set_to_none=True)
loss_g.backward()
optimizer_g.step()
set_requires_grad(critic, True)
```

**Unit gate:** after one generator backward pass, at least one parameter in the intended stage must have finite nonzero adversarial gradient, and every frozen/non-target stage must have `grad is None` or exactly zero. This test would fail immediately for the current `model.sample()` and is therefore mandatory before any expensive run.

## 5. Optional p4 reconstruction model

The existing XGBoost reconstruction evaluator is not differentiable, so it cannot be inserted directly into the loss. A neural p4 regressor could be trained only on Geant4 training events, frozen, and applied to generated showers. Calorimeter GAN work has reported benefits from an auxiliary regressor in a multitask objective ([Auxiliary-regressor GAN](https://arxiv.org/abs/2207.06329)).

However, a frozen regressor is a learned proxy that a generator can exploit, and correct reconstructed p4 does not imply a correct shower distribution. Therefore:

- do not include it in the first dynamic-critic experiment;
- condition the critic on p4 first;
- if later added, use a three-model regressor ensemble trained on Geant4 train only;
- use normalized energy Huber loss plus an angular loss;
- cap its gradient contribution at a proposed 5% of the base-gradient norm;
- monitor disagreement across the regressor ensemble;
- keep the independent XGBoost evaluator external and never train the neural regressor on generated events.

Training the regressor on generated outputs would move the target toward the generator and erase its meaning as a Geant4-derived constraint.

## 6. Evaluation and QC system

No single metric is sufficient. The CaloChallenge compares 31 models using one-dimensional observables, KPD/FPD, binary and multiclass classifiers, speed and model size ([CaloChallenge](https://arxiv.org/abs/2410.21611)). Statistical-distance research likewise shows that C2ST, MMD, sliced Wasserstein and Fréchet-style distances have different sensitivities and failure modes ([Practical Statistical Distances](https://arxiv.org/abs/2403.12636)).

### Required metrics for every promoted candidate

| Domain | Metrics |
|---|---|
| Structural | exact total/layer energy closure, exact requested/realized counts, valid-channel-only support, threshold feasibility, nonnegative finite energies |
| Response | zero fraction; cap pile-up; mean/resolution/quantiles/tails; PIT/rank calibration by energy/direction |
| Longitudinal | first/last/active counts; ECAL fraction; per-layer mean/variance; layer covariance and Correlation Frobenius Distance |
| Support/topology | edge co-occupancy, connected components, pair distances, local density, eccentricity, count-conditioned versions |
| Cell-energy morphology | hit spectrum, top-1/top-5 fractions, Gini, radial moments, centroid, local smoothness |
| Distributional | high-level C2ST, geometry-aware low-level C2ST, KPD/FPD or a validated detector-domain embedding, MMD/sliced Wasserstein |
| Diversity/memorization | repeated-condition diversity, nearest-neighbor train/validation ratios, exact/near duplicate rate, coverage |
| Downstream | frozen p4 reconstruction and any experiment-specific reconstructed observables |
| Systems | synchronized batch-size-matched latency, throughput, peak memory, model size |

Lantern’s correlation metric and graph-Laplacian idea are useful diagnostics/candidates, but its July-2026 result is a new single-setting preprint and should be replicated rather than treated as settled ([Lantern](https://arxiv.org/abs/2607.25060)). Full-physics work also shows that single-particle metrics are not the endpoint: realistic integration, reconstruction and multi-particle/full-physics benchmarks can change the practical conclusion ([Full Physics Benchmark](https://arxiv.org/abs/2511.17293)).

### Statistical protocol

- Establish truth-half floors on validation for every metric and energy bin.
- Use paired bootstrap confidence intervals with identical truth events/conditions across candidates.
- Use three generator seeds for every final candidate and three independent C2ST seeds/architectural variants.
- Correct for multiple candidate comparisons or explicitly label exploratory screens.
- If monitoring sequentially, predeclare stopping rules; anytime-valid sequential C2ST methods exist for repeated testing ([E-C2ST](https://arxiv.org/abs/2210.13027)).
- Keep the test split closed until architecture, loss weights, checkpoint rule and thresholds are frozen.

### Proposed screen/promotion gates

These are recommended preregistration values, not established scientific constants:

1. all structural invariants pass on every event;
2. no primary normalized metric degrades by more than 5% relative to its truth-half-normalized baseline;
3. high-level C2ST improves by at least 0.03 absolute in the one-seed screen and low-level C2ST moves in the same direction;
4. at least one predeclared downstream reconstruction error improves by 10% relative, with none worsening more than 5%;
5. critic train-minus-holdout AUROC gap stays below 0.10;
6. adversarial gradient ratio stays below 0.25 and does not become nonfinite;
7. no diversity/memorization gate fails;
8. promoted changes reproduce across three generator seeds before any test evaluation;
9. the project’s final provisional target remains C2ST AUROC at or below 0.65, but it must be accompanied by the other metrics.

Abort an adversarial run if critic holdout AUROC remains above 0.98 while generator adversarial gradients collapse, if the train/holdout critic gap exceeds 0.10 for three evaluations, if any structural invariant fails, or if a predeclared primary metric regresses more than 5% without recovery during the patience window.

## 7. Minimum credible experiment matrix

Use the same deterministic split, seed, minibatch order, optimizer budget and evaluation bank for all screen runs. First screen one generator seed; promote only winners to two additional generator seeds and then the full training dataset.

| ID | Single isolated change | Purpose | Promotion condition |
|---|---|---|---|
| B0 | Corrected scheduler baseline, current model | causal reference | reaches declared endpoint; complete metric suite |
| B1 | B0 on the proposed 90% generator partition | data-partition control | establishes cost of critic holdout |
| R1 | bounded positive response spline only | remove double-zero/cap artifact | zero and response metrics improve without other regressions |
| E1 | hierarchical ECAL-start only | recover rare layer 0 | ECAL prevalence/energy close with calibrated probability |
| L1 | compact span-plus-gaps activity/count model | cheap longitudinal dependence | correlation gain per latency |
| L2 | autoregressive activity/count model | stronger dependence | beat L1 significantly enough to justify latency |
| F1 | OT-CFM profile coupling only | straighter profile flow | better covariance/C2ST or fewer integration steps |
| S0 | best supervised combination of R1/E1/L*/F1 | stable pre-adversarial base | wins Pareto comparison across primary metrics |
| D1a | share-only critic, gradient ratio 5% | low-risk adversarial test | morphology improves, stability gates pass |
| D1b | share-only critic, gradient ratio 10% | loss-strength screen | compare with D1a |
| D1c | share-only critic, gradient ratio 20% | upper screen | reject if conflict/regression |
| D1r | best D1 with no replay/current-only | replay ablation control | quantify mixed replay contribution |
| D1m | best D1 with mixed replay | proposed dynamic critic | must outperform D1r across seeds |
| D1cdown | best D1 + terminal 20% base-only cooldown | conflict ablation | keep only if reproducible |
| D2 | profile-only critic | longitudinal refinement | only after D1 success |
| D3 | support critic with SIMPLE | topology refinement | only after support diagnostics prove need |
| P1 | frozen neural p4 regressor auxiliary | downstream proxy | only after dynamic critic is isolated |
| D4 | full relaxed shadow sampler | end-to-end adversarial signal | only after D1–D3 independently succeed |

Do not combine multiple unproven changes in the screen. Once isolated winners exist, build `S0` in the ranked order and re-run the control so interaction effects are visible.

## 8. Implementation map and verification gates

### New modules

- `src/cbsc_zdc/models/critic.py`: conditional graph/layer/global critic.
- `src/cbsc_zdc/training/replay.py`: stratified capacity-bounded replay with checkpoint metadata.
- `src/cbsc_zdc/training/adversarial.py`: D/G step functions, R1, gradient-ratio calibration and gradient-conflict logging.
- `src/cbsc_zdc/models/differentiable_sampling.py`: stage-specific samplers; keep separate from exact production sampling.

### Existing modules to revise

- `models/response.py`: bounded positive response and single zero hurdle.
- `models/profile.py`: hierarchical ECAL start and selected activity model.
- `models/counts.py`: selected contextual count model.
- `models/system.py`: explicit `sample_exact()` and stage samplers; never silently change the existing exact path.
- `models/support.py`: leave exact decoder intact; add a research-only estimator interface for D3.
- `training/trainer.py`: explicit adversarial mode, optimizers, devices, checkpoints and resume state.
- evaluation modules: correlations, support topology, truth floors, replay/critic diagnostics.

### Required unit/integration gates before GPU training

1. exact sampler regression outputs match the prior implementation for fixed state/seed where intended;
2. response zeros have one cause only;
3. stage D1 adversarial gradient reaches share parameters and no others;
4. D2 gradient reaches profile flow and no discrete head;
5. D3 estimator returns exact-k hard forward masks and finite surrogate gradients;
6. replay never accepts validation/test IDs and preserves all strata under eviction;
7. checkpoint resume restores both optimizers, critic, replay metadata, lambda schedule, RNG states and exact experiment step;
8. one CPU tiny-geometry overfit test shows critic loss decreases and generator adversarial direction increases the critic’s realness score;
9. one-GPU and two-GPU implementations agree within declared numerical tolerance on a fixed minibatch;
10. external C2ST code/model weights are never imported into training modules.

### Suggested local verification commands after implementation

The precise test filenames will depend on implementation, but the intended interface is:

```bash
cd /path/to/CBSC_ZDC_audit_bundle
python -m pytest -q tests/test_response.py tests/test_differentiable_sampling.py
python -m pytest -q tests/test_critic.py tests/test_replay.py tests/test_adversarial_gradients.py
python -m pytest -q tests/test_exact_decoder.py tests/test_resume.py
python -m cbsc_zdc.cli train --config configs/experiments/d1_share_critic_smoke.yaml
python -m cbsc_zdc.cli evaluate --config configs/experiments/d1_share_critic_smoke.yaml --split validation
```

Expected smoke evidence: all tests pass; structural failure count is zero; adversarial-gradient test names the intended nonzero parameter set; replay reports zero non-train IDs; the training log contains critic train/holdout metrics, fresh/replay composition, gradient ratio/cosines and generator checkpoint hashes.

## 9. Complete intervention decision log

This is an auditable hypothesis/decision log, not private hidden chain-of-thought. It records every substantive intervention considered in this analysis, its evidence, fastest QC test and disposition.

| # | Idea | Evidence/concern | Fastest QA/QC or falsification | Decision |
|---:|---|---|---|---|
| 1 | Finish corrected scheduler before model changes | exact inherited-`T_max` confound in bundle | monotone LR and endpoint evaluation | **Must do first** |
| 2 | Train on the full available training split | current pilot uses about 4.3%; underfit/capacity claims premature | matched pilot/full learning curves after architecture screen | **Must do for final** |
| 3 | Bounded spline for positive response | double-zero code path; spline likelihood precedent | zero-cause unit test, cap audit, binned calibration | **High priority** |
| 4 | Tune visibility temperature only | may calibrate Bernoulli but cannot remove continuous-branch zeros | isolate hurdle vs positive-zero contributions | **Diagnostic only** |
| 5 | Hierarchical ECAL-start head | rare layer-0 deficit and flat 65-way competition | truth-forced first-layer calibration | **High priority** |
| 6 | Add focal/class-weighted ECAL loss immediately | can distort physical prevalence/calibration | compare unweighted calibrated NLL first | **Defer** |
| 7 | Autoregressive active layers | current independent Bernoulli draws miss transitions | truth transition/gap analysis | **Keep if compact model insufficient** |
| 8 | Span-plus-gaps activity model | likely cheaper if shower activity nearly contiguous | measure fraction explained and gap statistics | **Screen first** |
| 9 | Autoregressive layer counts | current independent count draws miss correlations | residual count-correlation matrix | **Keep if residual is significant** |
| 10 | OT-CFM for profile | flow-matching research reports straighter/easier paths | identical-seed coupling ablation | **Screen** |
| 11 | OT-CFM directly across share supports | transport across incompatible masks may be unphysical | group by identical structure; measure coverage | **Defer** |
| 12 | Increase width/depth | no full-data underfit proof; raises compute and critic capacity race | train/validation loss gap and capacity scaling | **Reject for now** |
| 13 | Remove exact decoder | would sacrifice the project’s core closure/count guarantees | none justified | **Reject** |
| 14 | Graph-Laplacian auxiliary loss | recent positive single-setting result; direction may conflict | gradient cosine and topology/FPD ablation | **Screen only after diagnostics** |
| 15 | Pairwise support/neighborhood loss | directly targets co-occupancy if it is wrong | edge/distance-conditioned residuals | **Screen if needed** |
| 16 | Shared event latent for all heads | could capture global correlations but may be ignored without inference/MI control | latent sensitivity and mutual-information proxy | **Defer** |
| 17 | Full dynamic classifier on current `sample()` | current path has no gradients and hard discrete decisions | nonzero-target-gradient unit test | **Reject as written** |
| 18 | Staged share/profile critic | creates a clean differentiable path with truth-forced structure | D1/D2 gradient-isolation tests | **Recommended** |
| 19 | Retrain classifier from scratch every 20 epochs | discards boundary, introduces periodic shocks | continuous-vs-reset ablation | **Reject default** |
| 20 | Keep one frozen classifier forever | becomes stale/exploitable as generator changes | score by generator age | **Reject** |
| 21 | Store all generated history | unbounded and dominated by obsolete defects | age-conditioned critic accuracy | **Reject** |
| 22 | Train only against best-epoch fakes | stale; permits cycling to forgotten modes | fresh-only critic score | **Reject** |
| 23 | Bounded fresh/recent/anchor replay | history-buffer precedent; preserves current focus | replay-composition ablation | **Recommended** |
| 24 | Make adversarial loss dominant | risks improving classifier score while breaking likelihood/physics | gradient ratio/cosines and structural/physics gates | **Reject** |
| 25 | Fixed small adversarial gradient ratio | interpretable and preserves base objective | 5/10/20% screen | **Recommended** |
| 26 | Automatic GradNorm/PCGrad/ConFIG | recent calorimeter result shows possible severe regressions | direct matched ablation only | **Do not default** |
| 27 | Terminal base-only cooldown | recent conflict-aware study supports it for a conflicting loss | 20% cooldown ablation | **Screen** |
| 28 | Conditional projection critic | critic must judge `p(shower|p4)`, not only marginal shower law | condition-shuffle test | **Recommended** |
| 29 | Unconditional critic | can accept wrong condition-response mapping | train condition-aware probe | **Reject** |
| 30 | Spectral normalization + R1 | strong stabilization precedent | R1 coefficient and gradient/logit monitoring | **Recommended screen** |
| 31 | WGAN-GP as assumed cure | useful method, but finite-update convergence not universal | logistic-R1 vs WGAN-GP ablation | **Alternative, not default** |
| 32 | PacGAN sample packing | can reduce mode collapse | only if repeated-condition diversity collapses | **Contingency** |
| 33 | Unrolled GAN | may improve diversity/stability but is expensive | only after simpler controls fail | **Defer** |
| 34 | SIMPLE exact-forward support estimator | directly designed for k-subset gradients | finite-difference bias/variance slice test | **D3 candidate** |
| 35 | Straight-through Gumbel top-k without estimator QA | biased and easy to mistake for exact gradient | compare with SIMPLE/finite differences | **Reject default** |
| 36 | Full relaxed shadow sampler | only route for end-to-end pathwise critic, but changes many variables | promote only after isolated D1–D3 | **Long-term** |
| 37 | Frozen neural p4 regressor loss | calorimeter precedent, downstream relevance | regressor ensemble/disagreement and adversarial-gaming checks | **Later, small weight** |
| 38 | Train p4 regressor on generated events | moves the target toward generator | distribution-drift check | **Reject** |
| 39 | Use existing XGBoost directly in loss | nondifferentiable | gradient unit test | **Impossible as written** |
| 40 | Select candidates using C2ST alone | classifier-specific blind spots and overfitting | multi-metric Pareto evaluation | **Reject** |
| 41 | Repeatedly inspect test during iteration | contaminates final claim | access manifest/test event count | **Reject** |
| 42 | Add CFD/correlation matrices | current metrics undermeasure correlations | truth-half floors and bootstrap | **Recommended** |
| 43 | Add KPD/FPD/MMD/SW | benchmark precedent; complementary sensitivities | truth-half and model-ranking stability | **Recommended** |
| 44 | Add topology/component metrics | support mismatch can hide from current features | per-layer/count truth comparison | **Recommended** |
| 45 | Use low-level point/graph representation | natural for sparse high granularity; full-physics work favors point-cloud tradeoff | matched dense/point baseline only if feasible | **Keep architecture direction** |
| 46 | Add a postprocessing network | BIB-AE precedent, but can hide upstream defects and add latency | only after causal head fixes, with exact closure | **Backup only** |
| 47 | Full-physics benchmark immediately | important eventually, but single-shower fidelity is not yet established | pass preregistered single-shower gates first | **Defer, then require** |
| 48 | Async dual-GPU critic immediately | stale critic becomes extra variable | synchronous correctness/performance baseline | **Defer** |
| 49 | Synchronous 4090-generator/3090-critic | preserves current boundary and uses both GPUs | one-vs-two-GPU numerical/throughput check | **Recommended first implementation** |
| 50 | Use validation-selected historical anchors in replay | acceptable in development but increases selection coupling | log checkpoint rule; freeze before final test | **Use sparingly and transparently** |
| 51 | Mixture of generator experts by response regime | ZDC-specific work reports gains from specialized experts, but routing can fragment data and create boundaries | cluster residuals by condition/regime; compare one model with equal parameter budget | **Contingency after full-data baseline** |
| 52 | Replace the structured model with latent flow matching | ZDC-specific work reports very fast latent FM, but this would discard exact structural guarantees | matched fidelity/speed/exact-closure baseline | **Benchmark alternative, not an immediate fix** |
| 53 | Replace with diffusion | ZDC precedent reports strong fidelity but sampling cost/structure differ | matched detector/data/metric benchmark | **Research baseline only** |
| 54 | Output-variability-scaled loss | recent ZDC IAF work reports spatial/morphology benefits, but the abstract is insufficient to specify a correct implementation | reproduce from full method/code before any local ablation | **Investigate, do not guess** |

Related contingency research: PacGAN feeds packs of samples to the discriminator and reports reduced mode collapse ([PacGAN](https://arxiv.org/abs/1712.04086)); unrolled GANs anticipate discriminator updates and can improve stability/diversity at added cost ([Unrolled GAN](https://arxiv.org/abs/1611.02163)). Neither is the first intervention here. A postprocessing network has improved differential calorimeter distributions in BIB-AE work, but it should not precede identifiable upstream fixes ([BIB-AE](https://arxiv.org/abs/2005.05334)).

## 10. Research interpretation for this project

Prior calorimeter research supports the project’s central premise: learned generative surrogates can provide large speedups, and flows, GANs, diffusion/flow-matching models and point-cloud methods can all achieve useful fidelity. Early CaloGAN work demonstrated the promise and phase-space challenges of adversarial calorimeter simulation ([CaloGAN](https://arxiv.org/abs/1712.10321)); later CaloShowerGAN and hadronic BIB-AE/WGAN studies extended the evidence ([CaloShowerGAN](https://arxiv.org/abs/2309.06515), [Hadrons Better, Faster, Stronger](https://arxiv.org/abs/2112.09709)). CaloFlow showed stable flow-based fidelity and the diagnostic value of classifier separability, while CaloFlow II showed that speed can sometimes be recovered through distillation and specialized losses ([CaloFlow II](https://arxiv.org/abs/2110.11377)). Relational and self-supervised objectives have also improved fidelity/diversity in ultra-high-granularity calorimeter GANs ([IEA-GAN](https://arxiv.org/abs/2303.08046)).

The most directly adjacent ZDC literature strengthens the case for **flow-based baselines and explicit response-regime analysis**, but it does not validate this particular CBSC geometry or its current outputs. ALICE-ZDC diffusion work reports its best fidelity among the authors’ baselines and a useful fidelity/speed trade-off ([ZDC diffusion](https://arxiv.org/abs/2406.03233)). A later ZDC flow-matching study reports a ZN Wasserstein score of 1.27 at 0.46 ms/sample and a latent-FM time of 0.026 ms/sample, on its own data and metrics ([ZDC flow matching](https://arxiv.org/abs/2507.18811)). ExpertSim reports that a mixture of generative experts helps when response regimes vary substantially ([ExpertSim](https://arxiv.org/abs/2508.20991)). A 2025 inverse-autoregressive-flow preprint reports an output-variability scaling mechanism aimed at morphology and rare artifacts, but its abstract alone is not enough to recreate the method safely ([ZDC IAF](https://arxiv.org/abs/2512.20346)). These papers motivate matched external baselines and residual clustering; their numbers are not directly comparable to CBSC-ZDC because the detector, preprocessing and metrics differ.

What the literature does **not** justify is assuming that a dynamic classifier automatically fixes the audited model. Adversarial objectives are powerful but introduce a second optimizer, nonstationarity, capacity balance, possible mode collapse and learned-metric gaming. Here the full sampler is additionally discrete and explicitly non-grad. The scientifically defensible use is therefore staged and diagnostic: first remove identifiable likelihood/head defects, then give a regularized conditional critic a narrow differentiable responsibility, and promote only through independent metrics and downstream reconstruction.

The CBSC-ZDC architecture has an important strength worth preserving: it models sparse support and positive shares separately and decodes exact counts and energy closure. Point-cloud/graph representations are well motivated for sparse high-granularity detectors; comparative work and a 2025 full-physics benchmark report favorable point-cloud speed/accuracy tradeoffs ([Point-cloud vs image-based calorimeter simulation](https://arxiv.org/abs/2307.04780), [Full Physics Benchmark](https://arxiv.org/abs/2511.17293)). The correct improvement strategy is to improve the probability laws feeding the exact decoder, not to discard the decoder.

## 11. Source register

All external sources used in the analysis are listed here; links are to primary papers/preprints.

1. Goodfellow et al., **Generative Adversarial Nets** — [arXiv:1406.2661](https://arxiv.org/abs/1406.2661).
2. Gulrajani et al., **Improved Training of Wasserstein GANs** — [arXiv:1704.00028](https://arxiv.org/abs/1704.00028).
3. Heusel et al., **GANs Trained by a Two Time-Scale Update Rule Converge to a Local Nash Equilibrium** — [arXiv:1706.08500](https://arxiv.org/abs/1706.08500).
4. Mescheder et al., **Which Training Methods for GANs do actually Converge?** — [arXiv:1801.04406](https://arxiv.org/abs/1801.04406).
5. Miyato et al., **Spectral Normalization for Generative Adversarial Networks** — [arXiv:1802.05957](https://arxiv.org/abs/1802.05957).
6. Miyato and Koyama, **cGANs with Projection Discriminator** — [arXiv:1802.05637](https://arxiv.org/abs/1802.05637).
7. Shrivastava et al., **Learning from Simulated and Unsupervised Images through Adversarial Training** — [arXiv:1612.07828](https://arxiv.org/abs/1612.07828).
8. Lin et al., **PacGAN: The power of two samples in generative adversarial networks** — [arXiv:1712.04086](https://arxiv.org/abs/1712.04086).
9. Metz et al., **Unrolled Generative Adversarial Networks** — [arXiv:1611.02163](https://arxiv.org/abs/1611.02163).
10. Jang et al., **Categorical Reparameterization with Gumbel-Softmax** — [arXiv:1611.01144](https://arxiv.org/abs/1611.01144).
11. Paulus et al., **Gradient Estimation with Stochastic Softmax Tricks** — [arXiv:2006.08063](https://arxiv.org/abs/2006.08063).
12. Ahmed et al., **SIMPLE: A Gradient Estimator for k-Subset Sampling** — [arXiv:2210.01941](https://arxiv.org/abs/2210.01941).
13. Durkan et al., **Neural Spline Flows** — [arXiv:1906.04032](https://arxiv.org/abs/1906.04032).
14. Lipman et al., **Flow Matching for Generative Modeling** — [arXiv:2210.02747](https://arxiv.org/abs/2210.02747).
15. Tong et al., **Improving and Generalizing Flow-Based Generative Models with Minibatch Optimal Transport** — [arXiv:2302.00482](https://arxiv.org/abs/2302.00482).
16. Krause and Shih, **CaloFlow: Fast and Accurate Generation of Calorimeter Showers with Normalizing Flows** — [arXiv:2106.05285](https://arxiv.org/abs/2106.05285).
17. Krause and Shih, **CaloFlow II: Even Faster and Still Accurate Generation of Calorimeter Showers with Normalizing Flows** — [arXiv:2110.11377](https://arxiv.org/abs/2110.11377).
18. Kansal et al., **L2LFlows: Generating High-Fidelity 3D Calorimeter Images** — [arXiv:2302.11594](https://arxiv.org/abs/2302.11594).
19. Paganini et al., **CaloGAN** — [arXiv:1712.10321](https://arxiv.org/abs/1712.10321).
20. CaloShowerGAN collaboration, **CaloShowerGAN** — [arXiv:2309.06515](https://arxiv.org/abs/2309.06515).
21. Buhmann et al., **Hadrons, Better, Faster, Stronger** — [arXiv:2112.09709](https://arxiv.org/abs/2112.09709).
22. Buhmann et al., **Getting High: High Fidelity Simulation of High Granularity Calorimeters with High Speed** (BIB-AE) — [arXiv:2005.05334](https://arxiv.org/abs/2005.05334).
23. Hashemi et al., **GAN with an Auxiliary Regressor for the Fast Simulation of the Electromagnetic Calorimeter Response** — [arXiv:2207.06329](https://arxiv.org/abs/2207.06329).
24. IEA-GAN authors, **IEA-GAN: ... Ultra-High Granularity Calorimeters** — [arXiv:2303.08046](https://arxiv.org/abs/2303.08046).
25. Lopez-Paz and Oquab, **Revisiting Classifier Two-Sample Tests** — [arXiv:1610.06545](https://arxiv.org/abs/1610.06545).
26. Shekhar and Ramdas, **E-C2ST: ... Anytime-Valid Inference** — [arXiv:2210.13027](https://arxiv.org/abs/2210.13027).
27. Bischoff et al., **A Practical Guide to Statistical Distances for Evaluating Generative Models in Science** — [arXiv:2403.12636](https://arxiv.org/abs/2403.12636).
28. Krause et al., **CaloChallenge 2022: A Community Challenge for Fast Calorimeter Simulation** — [arXiv:2410.21611](https://arxiv.org/abs/2410.21611).
29. Ahmad et al., **Lantern: Conflict-Aware Gradient Blending for Physics-Guided Diffusion Models in Calorimeter Simulation** — [arXiv:2607.25060](https://arxiv.org/abs/2607.25060). This is a very recent v1 preprint and is treated as provisional evidence.
30. Buss et al., **A First Full Physics Benchmark for Highly Granular Calorimeter Surrogates** — [arXiv:2511.17293](https://arxiv.org/abs/2511.17293).
31. **Point-cloud and image-based models for calorimeter shower fast simulation** — [arXiv:2307.04780](https://arxiv.org/abs/2307.04780).
32. Kita et al., **Generative Diffusion Models for Fast Simulations of Particle Collisions at CERN** — [arXiv:2406.03233](https://arxiv.org/abs/2406.03233).
33. Wojnar, **Even Faster Simulations with Flow Matching: A Study of Zero Degree Calorimeter Responses** — [arXiv:2507.18811](https://arxiv.org/abs/2507.18811).
34. Będkowski et al., **ExpertSim: Fast Particle Detector Simulation Using Mixture-of-Generative-Experts** — [arXiv:2508.20991](https://arxiv.org/abs/2508.20991).
35. Majerz et al., **Inverse Autoregressive Flows for Zero Degree Calorimeter fast simulation** — [arXiv:2512.20346](https://arxiv.org/abs/2512.20346).

## 12. Bottom line

The dynamic classifier idea is worth testing, but the scientifically strongest version is **continuous, conditional, regularized, replay-aware, and staged**. The current full sampler cannot receive its gradient. Fix the identifiable response and rare-ECAL defects first, add missing longitudinal/topological diagnostics, then begin with a share-only critic under truth-forced structure. Keep fresh samples dominant, retain only bounded recent/anchor history, use separate critic and evaluation classifiers, measure gradient conflict, and require multi-metric/three-seed/downstream gains before promoting any adversarial change.
