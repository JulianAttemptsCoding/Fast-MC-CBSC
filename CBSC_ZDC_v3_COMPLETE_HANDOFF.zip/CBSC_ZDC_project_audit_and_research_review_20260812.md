# CBSC–ZDC audit-bundle review

**Archive reviewed:** `CBSC_ZDC_audit_bundle_20260812.zip`  
**Review date:** 2026-08-12  
**Scope:** every archive member, including the contents and integrity of nested archives; current implementation, evidence, historical material, external evaluators, dashboard, and research context.

## Executive finding

CBSC–ZDC is trying to replace slow Geant4 neutron-shower simulation for a high-granularity zero-degree calorimeter with a conditional generative surrogate. Given an incident neutron four-vector, it generates a sparse 6,790-channel energy-deposit pattern over 65 longitudinal layers. Its most distinctive engineering choice is to factor the shower into explicit, auditable decisions—whether it is visible, how much total energy is deposited, where it starts, which layers are active, how many cells fire, which exact cells fire, and how energy is divided among them—then enforce support, count, non-negativity, and energy-closure constraints in the decoder.

The project has **established a serious, reproducible implementation and audit framework**, but it has **not established Geant4 fidelity or production readiness**. The current validation evidence says the generated showers remain easy to distinguish from Geant4: hybrid classifier two-sample-test AUROC is about **0.862–0.873**, and a high-level classifier reaches **0.895–0.929**. Downstream four-momentum reconstruction is worse than the Geant4 reference by roughly **1.4–2.5×** on key error/spread measures. The training campaign was also confounded by a resumed cosine-scheduler state that repeatedly reheated the learning rate; the corrective experiment was still running when this bundle was built.

My overall assessment is therefore:

> **A scientifically promising and unusually well-audited FastMC research platform, with exact structural behavior and useful negative evidence, but not yet a faithful or production-qualified Geant4 surrogate.**

## 1. Project goal

The operational goal reconstructed from the specification, guide, code, configs, and evidence is:

1. Read neutron primaries and sparse Geant4 energy deposits using a frozen detector geometry and data contract.
2. Train a four-momentum-conditioned generator on the primary **50–250 GeV kinetic-energy domain**. The converted source covers approximately 0–300 GeV, but 50–250 GeV is the primary claim domain.
3. Generate one sparse raw-deposit vector with exactly 6,790 detector channels and 65 layers.
4. Make impossible outputs impossible by construction: no negative energy, no invalid-cell deposits, exact requested/realized support counts, exact zeros outside support, and energy closure within a floating-point-aware tolerance.
5. Demonstrate not just structural validity, but statistical fidelity to held-out Geant4, robustness across three training seeds, downstream reconstruction parity, no memorization/collapse, and a measured speed advantage.

The bundle itself correctly distinguishes the first four engineering goals from the fifth scientific goal. That distinction is the central fact needed to understand the project.

## 2. General idea and architecture

```mermaid
flowchart TD
    A["Neutron four-vector"] --> B["Condition encoder"]
    B --> C["Visible + total response"]
    C --> D["First layer + active layers + profile"]
    D --> E["Per-layer hit counts"]
    E --> F["Exact support via Gumbel-Top-k"]
    F --> G["Positive energy-share flow"]
    G --> H["Exact sparse decoder"]
```

| Component | What the code does | Why it exists |
|---|---|---|
| Condition encoder | Encodes `log1p(K/100)`, direction `(ux, uy, uz)`, and log total incident energy from the neutron four-vector. | Makes the shower conditional on energy and direction while preserving the neutron mass-shell convention. |
| Response head | Models a visible/zero hurdle plus a four-component mixture in a transformed total-response variable; applies train-derived and absolute caps. | Separates real zero-response events from positive response and models the broad, multimodal total deposit. |
| Profile head | Predicts the first active layer, later active-layer mask, and a 65-layer energy profile with flow matching. | Captures longitudinal shower development while keeping inactive layers exactly empty. |
| Count head | Predicts a categorical positive-cell count per layer with masks for geometry, activity, and threshold feasibility. | Turns sparsity into an explicit random variable rather than an emergent thresholding artifact. |
| Support head | Scores cells on the frozen detector graph and selects exactly `k` without replacement with Gumbel-Top-k. | Produces a stochastic but exact discrete support. |
| Share head | Uses graph/layer context and a conditional flow to allocate positive energy shares over selected cells. | Models spatial morphology and intra-layer energy correlations. |
| Decoder/invariant gate | Places exact zeros outside support, normalizes shares to layer budgets, and checks non-negativity, support validity, counts, and closure. | Guarantees structural properties independently of whether the learned distribution matches Geant4. |

Training is staged in the order **response → profile → count → support → share → joint**. The implementation supports frozen initialization between stages, AdamW, gradient accumulation, AMP, per-update cosine annealing, checkpoint provenance, RNG restoration, exact mid-epoch recovery at optimizer boundaries, one-writer campaign locks, validation-only monitoring, and checkpoint-time structural gates.

The fixed joint loss has nine components: visible, response, first layer, layer activity, profile flow, count, support BCE, support ranking, and share flow. Default weights are `1, 1, 0.5, 0.5, 1, 0.75, 1, 0.25, 1`. A calibration utility can instead equalize median component-gradient norms measured on the shared condition encoder, clip the inverse weights to `[0.25, 4]`, and normalize their mean to one. The code labels this as a heuristic, not a proof of optimal weighting.

## 3. What is actually established

### Established by the bundle

- **Production conversion exists.** The project reports 764,940 converted Geant4 neutron events in 187 shards, with a canonical 612,482/76,158/76,300 train/validation/test split.
- **Geometry and schema are frozen.** The detector has 6,790 channels: 400 ECAL and 6,390 HCAL channels across 65 layers.
- **Structural generation works.** The exact decoder and invariant reports enforce support, counts, zeros, non-negativity, and closure. A 2026-08-04 failure is transparently traced to an absolute-only float32 diagnostic tolerance, not silently waived.
- **Operational recovery is real.** Checkpoints retain model, optimizer, scheduler, scaler, RNG, config, environment, stage, and provenance. Mid-epoch recovery reconstructs the same epoch permutation and resumes only at an optimizer boundary.
- **Pilot optimization has progressed.** Four calibrated families improved on their short initial runs; the best recorded pre-correction validation loss is 4.512721 at `dicos-e-02`, epoch 47.
- **Evaluation isolation has improved.** Current C2ST and four-momentum monitors use validation events and report zero test events used. External evaluators are declared descriptive and are not allowed to choose or tune the generator.
- **The audit bundle is byte-consistent under its current manifest.** `verify_bundle.py` verified all 1,512 manifested files with zero missing, changed, or unlisted members; `MANIFEST.sha256` intentionally does not list itself.

### Not established

- **Geant4 fidelity.** Current classifier tests strongly reject equality at the tested representation and sample size.
- **Three-seed generator replication.** The required three independent training seeds were not run; three evaluator seeds are not a substitute.
- **An untouched test set in the colloquial sense.** A historical isolated C2ST used 40,000 of 76,300 test events. A separate 2,000-event paired draw had an unresolved 200-event test overlap. The bundle estimates 36,100–36,300 test events remain untouched; it correctly avoids claiming the original test split is wholly untouched.
- **Full-corpus learning.** The training evidence uses a 26,624-train/6,656-validation pilot bank, about 4.3% of the converted corpus, not the full 612,482-event training split.
- **Downstream parity.** The external four-momentum reconstructor is a useful monitor, but FastMC error and spread are materially worse than its Geant4 reference.
- **Diversity/memorization acceptance.** The promised nearest-neighbor and diversity gates have not been completed.
- **Publication-scale speed.** There is no matched, end-to-end generation-speed claim including preprocessing, sampling steps, decoding, and device synchronization.
- **Full-physics integration.** Current evidence is single-neutron shower generation and descriptive reconstruction, not a detector-integrated multi-particle physics benchmark.

## 4. Current empirical result

### Training standings before the scheduler correction

| Family | Best validation loss | Epoch | Run |
|---|---:|---:|---|
| calibrated LR `3e-4` | **4.512721** | 47 | `dicos-e-02` |
| calibrated LR `1e-4`, half batch | 4.619967 | 33 | continuation family |
| calibrated LR `1e-4` | 4.635220 | 38 | `dicos-p9` |
| calibrated LR `3e-5` | 4.702203 | 36 | continuation family |

These rankings are not clean convergence evidence. Each resumed segment restored a `CosineAnnealingLR` state whose `T_max=6660` represented only six epochs. Repeated resumes therefore produced a roughly 12-epoch learning-rate sawtooth from about `3e-4` to `1e-6` and back. The bundle estimates the phase-driven validation swing at about 0.14, versus only about 0.04 trough-to-trough improvement. “Best checkpoints” were consequently scheduler troughs as well as model states.

The corrective campaign `camp-20260812-lr3e4-anneal` explicitly restarts the scheduler and anneals across 24 remaining epochs to absolute epoch 72. The bundle snapshot shows `dicos-f-01` still training, with only epochs 48–49 recorded: validation loss 4.61150 then 4.58285 as the restarted learning rate begins near `3e-4`. Those early values are not a completed result.

### Validation-only classifier two-sample tests

| Generator checkpoint | Hybrid AUROC, mean of 3 evaluator seeds | Seed range | High-level GBM AUROC | Condition-only control |
|---|---:|---:|---:|---:|
| `dicos-c-02`, epoch 34 | **0.862415** | 0.846275–0.875139 | **0.894731** | 0.500000 |
| `dicos-p9`, epoch 38 | **0.872656** | 0.864628–0.886064 | **0.929097** | 0.500000 |

Interpretation: the energy/condition matching control is at chance, so the separability is not a trivial condition mismatch. The high-level shower observables alone separate even better than the hybrid evaluator in these monitors, pointing directly at residual shower-shape and response defects. The project’s predeclared AUROC ≤0.65 gate is a project heuristic, not a universal literature threshold. A low score would only mean that evaluator failed to separate at that power; these high scores, however, are decisive evidence of a difference.

A historical test-split C2ST reported AUROC **0.99945 ± 0.00009**. It remains valuable negative evidence but is correctly archived and cannot be used to select a current checkpoint because it consumed test events.

### Downstream four-momentum reconstruction

The external XGBoost-based reconstructor was evaluated on 4,000 validation showers for each checkpoint. Ratios below are FastMC error divided by the Geant4-reference error under the same adapter and reconstructor.

| Metric | `dicos-c-02` e34 | `dicos-p9` e38 |
|---|---:|---:|
| Energy relative RMSE | **1.399×** | **1.619×** |
| Energy relative 68% width | **2.093×** | **2.521×** |
| Energy MAE | **1.726×** | **2.098×** |
| Median angular error | **1.173×** | **1.919×** |
| Macro RMS relative four-vector error | **1.416×** | **1.668×** |

The reconstructed mass-shell residual is approximately `2.55e-11 GeV²` for both FastMC and Geant4, which verifies the reconstructor’s algebraic constraint, not shower fidelity. Energy bias is −4.36% for e34 and −5.10% for e38, compared with −0.59% for the Geant4 reference.

### Specific physics defects recorded across the evidence

- Zero-response frequency can be about twice the Geant4 value at some checkpoints.
- ECAL layer 0 is underproduced by roughly two orders of magnitude in the cited diagnostic.
- A prior run showed mean response bias around +0.40 in the 100–125 GeV bin for 25 epochs.
- Response, hit-count, depth, radial-width, and concentration spreads do not all match even when some means look close.
- Current same-condition plots show plausible showers and some improved longitudinal means, but visibly incorrect event-to-event variation and a persistent early-layer mismatch.
- The training loss and the external physics metrics do not rank checkpoints identically; lower weighted validation loss has not guaranteed better reconstruction or C2ST.

## 5. Integrity and consistency audit

### Archive-level result

- ZIP size: **110,349,073 bytes**; extracted payload: **158,907,845 bytes**.
- Files: **1,513**; unsafe paths: 0; symlinks: 0; encrypted entries: 0.
- Outer ZIP test: clean.
- Current manifest: 1,512 entries, all verified; the manifest itself is the 1,513th file.
- Unique file hashes: 1,423; 90 members are non-canonical exact duplicates. Duplication is mainly mirrored evidence/graphics and is identified row-by-row in the ledger.
- All 522 PNGs decoded; all 37 SVGs parsed; all 352 JSON files and 70 YAML files parsed; all 246 Python files parsed to an AST; all six PPTX and three PDF files opened and were inventoried; CSV/JSONL/NDJSON, HTML, TypeScript/TSX, shell, TeX/BibTeX, and other text files decoded.
- Three Parquet files have valid `PAR1` headers/trailers; the ROOT fixture has a valid ROOT header. This review environment did not have `pyarrow`, `uproot`, or `torch`, so their numerical payloads and the reported 338-test suite were not independently re-executed here.

### Nested packages

| Nested artifact | Members | Result | Role |
|---|---:|---|---|
| `ZDC_accepted_xgb_study_package_20260711.zip` | 187 | ZIP test clean; sidecar checksum matches | Frozen accepted XGBoost reconstruction study, evidence, and figures. |
| `ZDC_MC_ROOT_VERTEX_ANALYSIS_v3.zip` | 26 | ZIP test clean | Historical ROOT/vertex analysis package supporting the reconstruction line of work. |
| `zdc_hybrid_source_accepted_xgb_20260711.tar.gz` | 54 | Tar test clean | Frozen hybrid-source code and metadata for the accepted reconstructor. |

### Stale or contradictory material

These do not invalidate the current manifest, but they matter to a reviewer:

1. **Old checksum lists are stale.** Running `sha256sum -c SHA256SUMS.txt` against this bundle produces eight missing-file errors and 100 checksum mismatches; one line is malformed by two concatenated paths. `SHA256SUMS.txt` and the adjacent 168-entry `MANIFEST.txt` belong to an older compact release. `MANIFEST.sha256` plus `verify_bundle.py` is the valid current verifier, but the obsolete files are insufficiently labeled and invite a false integrity alarm.
2. **Status instructions conflict by date.** `docs/FOCUSED_OPERATING_RULES.md` ends with “do not start or resume training yet” and an August 4 idle-GPU status. The August 12 campaign plan and `live_campaign_evidence/state.json` show that `dicos-f-01` is actively training. The former is a stale state snapshot embedded in a still-binding rules document.
3. **Test-count statements are chronological, not current.** Release notes say 18 tests, the root README says 90, and the audit README reports 338. The older values should be date/version labeled.
4. **The visual-layout contract lags its own catalog.** `exhibition/visual_layout.json` says latest observed/accepted/external epochs are 40/39/38, while the metrics catalog and continuation records extend to epoch 54 and internal training evidence extends farther. The visual files themselves parse, but this contract field is stale.
5. **Public figures lag internal standings.** The dashboard/current publication snapshot still emphasizes older p7/p9 evidence while the internal best is epoch 47. The bundle says this is an intentional publication delay during a moving correction experiment, but it means “current public” is not “latest internal.”
6. **A broken self-reference exists.** The live README refers reviewers to `AUDIT_README.md`; the actual file is `docs/AUDIT_BUNDLE_README.md`.
7. **The p10 tolerance rule changes experiment identity.** `dicos-p10` epoch 40 was quarantined when one 33.16 GeV sample had a `2.67e-5 GeV` layer-closure residual against a fixed `2e-5 GeV` tolerance, with all discrete invariants zero. The new rule `max(abs_tol, rel_tol × energy scale)` is technically justified for float32 summation, but comparisons across the rule change must remain labeled as a new declared experiment—as the bundle requires.

## 6. Whole-archive map

This table gives the role of every top-level area. The companion CSV is the exhaustive one-row-per-file log.

| Area | Files | Bytes | Role in the whole |
|---|---:|---:|---|
| `external_models/` | 686 | 64,911,601 | Frozen external C2ST and four-momentum repositories, source, audit records, accepted artifacts, nested packages, and their figures. They evaluate the generator but are prohibited from selecting/tuning it. |
| `exhibition/` | 298 | 31,124,934 | Current and archived figures, slide deck, metric catalog, source evidence, continuation histories, and static gallery. It is the human-facing scientific evidence layer. |
| `audit/` | 139 | 1,474,448 | Decisions, QA, failure analyses, campaign terminal analyses, determinism checks, outside audits, test-accounting, and negative-result records. |
| `configs/` | 77 | 215,473 | Frozen production, campaign, continuation, viability, and external-dependency contracts with hashes and allowed deltas. |
| `legacy/` | 65 | 2,425,440 | v2/v2.1 specifications and working materials retained as evidence only; not authoritative implementation. |
| `src/` | 46 | 287,164 | The active Python package: data conversion, geometry, model heads, flow losses, training, checkpoints, campaigns, evaluation, CLI, and cloud helpers. |
| `tests/` | 43 | 240,366 | Contract tests for data, invariants, stages, scheduler restart, recovery, campaign behavior, visualization, dashboard/exhibition, and reproducibility. |
| `scripts/` | 42 | 497,310 | Builders and verifiers for audit bundles, campaigns, continuations, diagnostics, external metrics, exhibitions, cloud staging, and failure recovery. |
| `dashboard/` | 41 | 55,930,346 | Next/React/Vinext status dashboard source plus large demo/current payloads and graphics. Its role is presentation, not authoritative model selection. |
| `docs/` | 22 | 261,975 | Binding implementation guide, operating/evaluation/loss/compute protocols, auditor prompts, and the current audit-bundle explanation. |
| root files | 21 | 911,436 | Entry-point README, operating contract, package/build metadata, paper/release provenance, current and legacy manifests, run logs, and bundle verifier. |
| `runs/` | 9 | 12,502 | Small reproducibility fixtures and resolved records, not full production checkpoints. |
| `requirements/` | 6 | 593 | CPU, GPU, cloud, evaluation, ROOT, and development dependency pins. |
| `vertex/` | 6 | 27,239 | Google Vertex job definitions and preparation/training launch helpers. |
| `live_campaign_evidence/` | 4 | 12,507 | Snapshot of the in-flight August 12 scheduler-correction campaign: state, events, and epochs 48–49. |
| `paper/` | 3 | 505,187 | Active v2.2 auditor specification in TeX/PDF plus bibliography. |
| `references/` | 3 | 3,826 | Supplied research source notes and preserved reference inputs. |
| `fixtures/` | 2 | 65,498 | Synthetic ROOT and geometry fixtures used for parsing/conversion tests, not physics training data. |

### What the major file classes do

- **522 PNG + 37 SVG files:** architecture diagrams, current and historical diagnostics, classifier/reconstruction results, loss trajectories, dashboard graphics, and slide-render media. Dimensions, hashes, scope, duplicates, and specific inferred roles are in the ledger. Current scientific plots were visually inspected; historical/external graphics were decoded and cross-referenced to their source metadata and titles.
- **352 JSON + 33 CSV + JSONL/NDJSON files:** immutable configs, evidence, metric payloads, manifests, histories, campaign events, dashboard payloads, and QA results. The ledger records keys, table shapes, epochs, and salient values.
- **246 Python files:** 46 active package modules, 43 active tests, 42 root scripts, plus self-contained external and legacy repositories. Each ledger row lists its classes/functions/tests and role.
- **157 Markdown + 17 text files:** specifications, procedures, audit findings, research notes, repository provenance, and historical logs. Each row includes the title, headings, line/word counts, and scope.
- **6 PPTX + 3 PDF files:** presentation/evidence decks and three generations of the auditor specification. Slide/page counts and titles are logged.
- **3 Parquet + 1 ROOT file:** small data/evaluator artifacts and a synthetic fixture. They are structurally recognized but were not numerically recomputed in this runtime.

## 7. File-by-file log

The companion ledger contains **exactly 1,513 data rows—one for every file in the outer ZIP**. It is intended to be filtered or sorted rather than pasted into this narrative. Its columns are:

| Column | Meaning |
|---|---|
| `file_number` / `path` | Stable enumeration and exact archive-relative path. |
| `bytes` / `sha256` / `mime_type` | Byte size, content identity, and detected format. |
| `top_level_area` / `scope_status` | Where the file belongs and whether it is current, audit, external, archived, legacy, fixture, or presentation material. |
| `specific_role` | File-specific explanation of what it says, implements, verifies, configures, records, or displays. |
| `content_or_result` | Headings, keys, table dimensions, salient metrics, archive membership, slide/page/image metadata, or format signature. |
| `lines` / `words` | Text extent where meaningful. |
| `duplicate_of` | Canonical identical file when the same bytes appear elsewhere. |
| `parse_status` | Format-aware read result; all 1,513 rows are `OK`. |

This is the definitive answer to “what role does every single file play.” It distinguishes mirrored evidence from independent evidence and prevents the 90 exact duplicates from being mistaken for 90 independent results.

## 8. What prior research says about the ideas

There is no peer-reviewed paper evaluating this exact 6,790-channel EIC-style detector, data split, preprocessing, and metric suite against CBSC–ZDC. Numerical scores from ALICE ZDC and CaloChallenge papers are therefore context, not an apples-to-apples leaderboard.

| Research line | What the literature establishes | Implication for CBSC–ZDC |
|---|---|---|
| Flow matching | [Flow Matching](https://arxiv.org/abs/2210.02747) trains continuous normalizing flows by regressing vector fields of conditional probability paths without simulating the ODE during training. | The profile/share-flow choice is methodologically mainstream and defensible. Its use alone does not establish calorimeter fidelity. |
| Exact sampling without replacement | [Gumbel-Top-k](https://proceedings.mlr.press/v97/kool19a.html) provides exact `k`-item sampling without replacement from categorical structure. | The support sampler has sound mathematical ancestry; CBSC–ZDC’s contribution is applying it inside a constrained shower factorization. |
| Hierarchical longitudinal modeling | [L2LFlows](https://arxiv.org/abs/2302.11594) improved high-granularity calorimeter generation by modeling layer-to-layer dependencies with separate conditional flows. | Explicit longitudinal factorization is well motivated. CBSC–ZDC should still ablate its first-layer/activity/profile hierarchy against a simpler joint model. |
| Irregular detector geometry | [CaloGraph](https://arxiv.org/abs/2402.11575) introduced graph diffusion for irregular calorimeter geometry. | A geometry graph is appropriate, but graph use is not novel by itself. A graph-free or local-neighborhood baseline is needed to demonstrate its value here. |
| Sparse/high-granularity representation | A direct [point-cloud versus image comparison](https://arxiv.org/abs/2307.04780) argues that point clouds preserve sparse information naturally and can be more compact. | CBSC–ZDC’s sparse support is aligned with the field, but a point-cloud generator is an important missing baseline. |
| Evaluation standards | [CaloChallenge 2022](https://arxiv.org/abs/2410.21611) compared 31 submissions with 1D observables, KPD/FPD, classifier AUCs, speed, and model size. | No single loss or diagnostic is sufficient. CBSC–ZDC’s candid C2ST and reconstruction monitors are good, but KPD/FPD-like joint metrics, correlation metrics, matched speed, and ablations are still owed. |
| ZDC diffusion | [ALICE ZDC diffusion work](https://arxiv.org/abs/2406.03233) reports improved fidelity and studies fidelity/speed trade-offs. | Diffusion/latent diffusion is a relevant baseline, though its detector and representation differ. |
| ZDC flow matching | [Even Faster Simulations with Flow Matching](https://arxiv.org/abs/2507.18811) reports ALICE ZN Wasserstein distance 1.27 at 0.46 ms/sample and latent-FM sampling at 0.026 ms/sample. | It validates the broad FM direction and shows that speed must be measured. Its scores cannot be directly compared with CBSC–ZDC’s validation loss or AUROC. A native reimplementation on the same data would be the fair test. |
| Multimodal ZDC response | [ExpertSim](https://arxiv.org/abs/2508.20991) uses a mixture of generative experts for varying/multimodal ALICE ZDC distributions. | CBSC–ZDC’s response mixture and hurdle acknowledge multimodality, but expert routing is a plausible baseline or extension if defects cluster by response regime. |
| Physics-aware morphology | [Inverse Autoregressive Flows for ZDC](https://arxiv.org/abs/2512.20346) adds a physics-based loss and variability scaling to improve spatial morphology and reports a faster teacher–student NF. | This directly reinforces the need to target CBSC–ZDC’s morphology and spread defects, while preserving evaluator isolation. |
| Full-physics validation | The [first full-physics benchmark for highly granular calorimeter surrogates](https://arxiv.org/abs/2511.17293) integrates models with DD4hep and evaluates reconstruction, multi-particle separation, and tau-decay physics. | Single-neutron histograms are not the finish line. The project’s downstream recon monitor is directionally right, but detector-integrated multi-particle/full-physics validation remains necessary. |
| Correlations and multi-loss conflict | The July 2026 [Lantern preprint](https://arxiv.org/abs/2607.25060) introduces a correlation Frobenius distance and reports that symmetric methods including GradNorm, PCGrad, IMTL-G, and ConFIG worsened FPD by 2–100× on one CaloChallenge setting, while conflict-aware blending preserved/improved fidelity. | CBSC–ZDC’s fixed inverse-gradient calibration should be treated cautiously. Add correlation/neighborhood metrics and inspect gradient conflicts before adding more auxiliary losses. This is a very recent single-setting preprint, not a universal theorem. |

### Research-level verdict

Research would likely view the architecture as **reasonable and potentially publishable**, especially the explicit sparse factorization, exact decoder, detector-graph conditioning, and unusually strong provenance/recovery discipline. But the individual ingredients all have precedents; the likely novelty is their **combination and audited application to this detector**, not a new generative principle.

To support a strong paper, the project needs to show that the combination earns its complexity. At minimum:

1. Complete the declared scheduler-correction experiment and repeat the chosen configuration with three independent generator seeds.
2. Move from the 4.3% pilot bank to the full frozen training split, without touching the remaining test holdout.
3. Compare against empirical resampling, a simple conditional baseline, graph-free and hierarchy-free ablations, a point-cloud model, and a same-data flow/diffusion baseline.
4. Add low-level and high-level C2ST, KPD/FPD-style joint metrics, layer/voxel correlation distance, neighborhood morphology, energy-bin calibration, and diversity/nearest-neighbor tests.
5. Diagnose loss-gradient conflict. Any classifier or physics-aware auxiliary loss must be a separately declared experiment and must not reuse the final evaluator for training or tuning.
6. Evaluate downstream reconstruction and full detector/physics behavior, not only structural invariants and single-particle shower summaries.
7. Benchmark end-to-end speed with matched batch size, hardware, precision, synchronization, integration steps, and decoding included.

If those tests succeed, the project could make a credible contribution: an interpretable, sparse, structurally exact, four-momentum-conditioned FastMC for an irregular high-granularity ZDC. If they fail, the existing bundle is still valuable as a well-documented case study showing that exact physics constraints and improving validation loss do not automatically produce distributional fidelity.

## 9. Bottom line

- **Goal:** accelerate neutron ZDC simulation while preserving sparse geometry, energy budgets, and Geant4-level shower statistics.
- **What it is now:** a mature implementation and audit/recovery system trained on a pilot subset, with a live scheduler-correction campaign.
- **Best proven property:** exact structural validity and unusually careful evidence/provenance handling.
- **Main scientific problem:** residual response and morphology differences remain large enough for classifiers to separate FastMC from Geant4 with AUROC up to 0.93, and downstream reconstruction is materially worse.
- **What research says:** the core ideas are well motivated, but fidelity requires broader metrics, ablations, multiple generator seeds, full data, speed measurements, and detector-integrated downstream tests. Current evidence does not support calling the model validated or production-ready.

## 10. Review limitations

“Read every file” was implemented as a complete format-aware archive pass: every member was opened, hashed, classified, and logged; text/code/config files were decoded or parsed; archives and office/PDF/image formats were inspected; current scientific documents and key figures were manually synthesized. This does not mean every pixel of every duplicated historical plot was interpreted as an independent experiment. Binary numerical recomputation of Parquet/ROOT/checkpoint content and the reported 338 tests was not possible in this runtime because `pyarrow`, `uproot`, and `torch` were absent. Those limits are recorded rather than silently converted into claims.
